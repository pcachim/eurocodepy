# eurocodepy v0.1

Functions to work with struuctural eurocodes. Material data is stored in a JSON file. Current materials in the database are:

* concrete (C20 to C90)
* timber (C, D, GL)
* reinforcement (S400, S500, A400, A500)
* structural steel

There are also some functions to work with material properties:

* creep_coef
* shrink_strain

